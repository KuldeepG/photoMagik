﻿karma-xml-reporter
==================

A Karma plugin. Report results in DanTup's xml format.
